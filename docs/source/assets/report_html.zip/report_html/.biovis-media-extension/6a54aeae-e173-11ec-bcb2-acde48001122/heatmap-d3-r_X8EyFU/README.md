Minimal example shiny app for the `d3heatmap` HTML widget package.

For more information, please see :  https://github.com/rstudio/d3heatmap

May be we need to try https://cran.r-project.org/web/packages/heatmaply/vignettes/heatmaply.html#customized-dendrograms-and-side-annotation